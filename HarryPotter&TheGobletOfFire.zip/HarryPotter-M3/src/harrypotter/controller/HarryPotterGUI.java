package harrypotter.controller;

import java.io.IOException;

import harrypotter.view.HarryPotterView;

public class HarryPotterGUI {
	public static void main(String[] args) throws IOException {
		new HarryPotterView();

	}

}
