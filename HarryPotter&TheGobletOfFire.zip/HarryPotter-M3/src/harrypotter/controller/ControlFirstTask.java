package harrypotter.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import harrypotter.exceptions.InCooldownException;
import harrypotter.exceptions.InvalidTargetCellException;
import harrypotter.exceptions.OutOfBordersException;
import harrypotter.view.FirstTaskView;

public class ControlFirstTask {
//	public ControlFirstTask(FirstTaskView x) {
//		x.getUseTrait().addActionListener(new ActionListener() {
//
//			public void actionPerformed(ActionEvent ae) {
//
//				try {
//					x.getTask1().getCurrentChamp().useTrait();
//					// System.out.print("malak");
//				} catch (InCooldownException | OutOfBordersException
//						| InvalidTargetCellException | IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//		});
//	}
}
